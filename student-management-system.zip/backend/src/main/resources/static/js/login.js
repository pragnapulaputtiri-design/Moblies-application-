async function login(){
 const username=document.getElementById('username').value;
 const password=document.getElementById('password').value;
 const r=await fetch('/api/auth/login',{
   method:'POST',
   headers:{'Content-Type':'application/json'},
   body:JSON.stringify({username,password})
 });
 const text=await r.text();
 document.getElementById('message').textContent=text;
 if(r.ok) window.location.href='/dashboard.html';
}
