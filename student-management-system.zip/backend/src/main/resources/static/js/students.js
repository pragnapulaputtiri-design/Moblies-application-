async function loadStudents(){
 const r=await fetch('/api/students');
 if(!r.ok){location.href='/login.html';return;}
 const data=await r.json();
 document.getElementById('students').innerHTML=data.map(s=>`
 <tr><td>${s.id}</td><td>${s.name}</td><td>${s.email}</td><td>${s.course}</td><td>${s.phone||''}</td>
 <td><button onclick="deleteStudent(${s.id})">Delete</button></td></tr>`).join('');
}
async function addStudent(){
 const student={
  name:document.getElementById('name').value,
  email:document.getElementById('email').value,
  course:document.getElementById('course').value,
  phone:document.getElementById('phone').value
 };
 await fetch('/api/students',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(student)});
 document.querySelectorAll('input').forEach(x=>x.value='');
 loadStudents();
}
async function deleteStudent(id){
 await fetch('/api/students/'+id,{method:'DELETE'});
 loadStudents();
}
loadStudents();
