package com.example.student.controller;

import com.example.student.model.Student;
import com.example.student.repository.StudentRepository;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/students")
public class StudentController {
    private final StudentRepository repo;

    public StudentController(StudentRepository repo) {
        this.repo = repo;
    }

    @GetMapping
    public List<Student> all() { return repo.findAll(); }

    @PostMapping
    public String create(@RequestBody Student student) {
        repo.save(student);
        return "Student added successfully";
    }

    @PutMapping("/{id}")
    public String update(@PathVariable Long id, @RequestBody Student student) {
        repo.update(id, student);
        return "Student updated successfully";
    }

    @DeleteMapping("/{id}")
    public String delete(@PathVariable Long id) {
        repo.delete(id);
        return "Student deleted successfully";
    }
}
