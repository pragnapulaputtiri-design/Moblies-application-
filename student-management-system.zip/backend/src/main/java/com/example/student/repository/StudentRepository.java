package com.example.student.repository;

import com.example.student.model.Student;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public class StudentRepository {
    private final JdbcTemplate jdbc;

    public StudentRepository(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public List<Student> findAll() {
        return jdbc.query("SELECT * FROM students ORDER BY id DESC",
            (rs, rowNum) -> new Student(
                rs.getLong("id"), rs.getString("name"), rs.getString("email"),
                rs.getString("course"), rs.getString("phone")));
    }

    public int save(Student s) {
        return jdbc.update("INSERT INTO students(name,email,course,phone) VALUES(?,?,?,?)",
            s.getName(), s.getEmail(), s.getCourse(), s.getPhone());
    }

    public int update(Long id, Student s) {
        return jdbc.update("UPDATE students SET name=?,email=?,course=?,phone=? WHERE id=?",
            s.getName(), s.getEmail(), s.getCourse(), s.getPhone(), id);
    }

    public int delete(Long id) {
        return jdbc.update("DELETE FROM students WHERE id=?", id);
    }
}
