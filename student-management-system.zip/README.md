# Student Management System

Full-stack Student Management System using:
- Java 17
- Spring Boot 3
- Spring Security
- JDBC
- MySQL
- HTML
- CSS
- JavaScript

## Requirements
Install:
1. JDK 17+
2. MySQL 8+
3. Maven 3.9+

## Database
1. Start MySQL.
2. Open `database/database.sql` in MySQL Workbench and run it.
3. The project is configured for:
   - Database: studentdb
   - Username: root
   - Password: root

If your MySQL password is different, change only the password in:
`backend/src/main/resources/application.properties`

## Run
Open a terminal in the `backend` folder and run:

mvn spring-boot:run

Then open:
http://localhost:8080/

## Demo login
Username: admin
Password: admin123

The application provides login, dashboard, add student, list/search, edit and delete.
